"""Small physical readback sweep, no TX; not an RF calibration."""
import argparse
import json
import sys
from pathlib import Path
import serial

sys.path.insert(0, "/home/kaboom/iq_arduino_20261020/websdr_qualification")
from qualify_protocol import Client, Evidence, ProtocolError

p = argparse.ArgumentParser()
p.add_argument("--out", required=True)
a = p.parse_args()
ev = Evidence(a.out)
port = serial.Serial(port=None, baudrate=115200, timeout=.05,
                     write_timeout=3, exclusive=True)
port.dtr = port.rts = False
port.port = "/dev/ttyUSB0"
port.open()
c = Client(port, ev)
report = {"frequencies": [], "gains": [], "retries": [], "completed": False}


def retry(label, action):
    for attempt in range(3):
        try:
            return action()
        except (ProtocolError, UnicodeError) as exc:
            row = {"label": label, "attempt": attempt + 1, "error": str(exc)}
            report["retries"].append(row)
            ev.append("retry", **row)
            c.synchronize()
            if attempt == 2:
                raise


try:
    identified = False
    for baud in (115200, 2000000):
        port.baudrate = baud
        try:
            c.synchronize(attempts=2, timeout=1)
            if c.ask("INFO") == "ESP8266SDR 6 burst 2048":
                identified = True
                break
        except (ProtocolError, UnicodeError):
            pass
    if not identified:
        raise RuntimeError("Receiver not identified at either supported boot/session speed")
    if port.baudrate != 115200:
        c.set_baud(115200)
    if c.ask("INFO") != "ESP8266SDR 6 burst 2048":
        raise RuntimeError("Unexpected receiver")
    retry("gain0", lambda: c.ok("GAIN MANUAL 0"))
    for frequency in range(2412, 2463):
        retry(f"freq{frequency}", lambda: c.ok(f"FREQ {frequency}"))
        row = retry(f"capture_freq{frequency}",
                    lambda: c.capture(32, raw=True, label=f"freq{frequency}"))
        if row["status"]["freq"] != frequency or row["status"]["gain"] != 0:
            raise RuntimeError("Readback differs from frequency/gain request")
        report["frequencies"].append(row)
    for gain in range(30):
        retry(f"gain{gain}", lambda: c.ok(f"GAIN MANUAL {gain}"))
        row = retry(f"capture_gain{gain}",
                    lambda: c.capture(32, raw=True, label=f"gain{gain}"))
        if row["status"]["gain"] != gain or not row["status"]["profile"]:
            raise RuntimeError("Gain profile/readback mismatch")
        report["gains"].append(row)
    retry("restoregain", lambda: c.ok("GAIN MANUAL 0"))
    retry("restorefreq", lambda: c.ok("FREQ 2462"))
    report["final_capture"] = retry("final2048",
                                   lambda: c.capture(2048, raw=True, label="final2048"))
    report["completed"] = True
finally:
    if not report["completed"]:
        try:
            c.synchronize()
            c.ok("GAIN MANUAL 0")
            c.ok("FREQ 2462")
            report["cleanup"] = "gain0/freq2462"
        except Exception as exc:
            report["cleanup_error"] = str(exc)
    port.close()
    Path(a.out, "summary.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"completed": report["completed"],
                  "frequencies": len(report["frequencies"]),
                  "gains": len(report["gains"]),
                  "retries": len(report["retries"])}))
