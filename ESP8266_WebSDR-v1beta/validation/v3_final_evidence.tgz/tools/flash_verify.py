"""Flash only the identified receiver, verify flash MD5, record a fresh boot."""
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, "/home/kaboom/.arduino15/packages/esp8266/hardware/esp8266/3.1.2/tools/esptool")
import esptool

p = argparse.ArgumentParser()
p.add_argument("--image", required=True)
p.add_argument("--source", required=True)
p.add_argument("--out", required=True)
p.add_argument("--verify-only", action="store_true")
p.add_argument("--boot-baud", type=int, default=2000000)
a = p.parse_args()
out = Path(a.out)
out.mkdir(parents=True, exist_ok=False)
data = Path(a.image).read_bytes()
record = {
    "source_sha256": hashlib.sha256(Path(a.source).read_bytes()).hexdigest(),
    "binary_sha256": hashlib.sha256(data).hexdigest(),
    "binary_bytes": len(data),
    "expected_md5": hashlib.md5(data).hexdigest(),
    "flash_written": not a.verify_only,
}
rom = esptool.ESP8266ROM("/dev/ttyUSB0", 115200)
try:
    rom.connect()
    record["mac"] = ":".join(f"{b:02x}" for b in rom.read_mac())
    if record["mac"] != "68:c6:3a:d6:0e:e8":
        raise RuntimeError("Refusing to touch an unexpected ESP8266: " + record["mac"])
    stub = rom.run_stub()
    if not a.verify_only:
        with open(a.image, "rb") as f:
            params = SimpleNamespace(
                addr_filename=[(0, f)], flash_size="4MB", flash_mode="dio",
                flash_freq="40m", erase_all=False, compress=True,
                no_compress=False, no_progress=True, verify=False,
                encrypt=False, force=False, no_stub=False,
            )
            esptool.write_flash(stub, params)
    record["flash_md5"] = stub.flash_md5sum(0, len(data)).lower()
    if record["flash_md5"] != record["expected_md5"]:
        raise RuntimeError("Flash differs from the compiled image")
    rom._port.baudrate = a.boot_baud
    rom._port.timeout = 0.05
    rom.hard_reset()
    raw = bytearray()
    end = time.monotonic() + 3
    while time.monotonic() < end:
        raw.extend(rom._port.read(max(1, min(65536, rom._port.in_waiting))))
    (out / "boot.bin").write_bytes(raw)
    (out / "boot.txt").write_text(raw.decode("latin1"), encoding="utf-8")
    record["boot_text"] = raw.decode("latin1")
finally:
    rom._port.close()
    (out / "flash.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
