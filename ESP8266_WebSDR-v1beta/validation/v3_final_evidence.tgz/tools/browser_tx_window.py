"""One bounded TX window for live browser QA; no receiver port access."""
import argparse
import json
import sys
import time
from pathlib import Path
import serial

sys.path.insert(0, "/home/kaboom/iq_arduino_20261020/websdr_qualification")
from qualify_protocol import Client, Evidence
from rf_runner import Tx

p = argparse.ArgumentParser()
p.add_argument("--out", required=True)
p.add_argument("--stop-only", action="store_true")
a = p.parse_args()
ev = Evidence(a.out)
port = serial.Serial(port=None, baudrate=115200, timeout=.05,
                     write_timeout=3, exclusive=True)
port.dtr = port.rts = False
port.port = "/dev/ttyUSB1"
port.open()
tx = Tx(Client(port, ev))
try:
    tx.synchronize()
    if not a.stop_only:
        tx.configure()
        print(json.dumps(tx.start()), flush=True)
        # The emitter also enforces its own 60-second deadline.
        time.sleep(55)
finally:
    try:
        for attempt in range(3):
            try:
                tx.synchronize()
                state = tx.stop()
                ev.append("final_tx_off", state=state)
                print(json.dumps(state), flush=True)
                break
            except Exception as exc:
                ev.append("stop_retry", attempt=attempt + 1, error=str(exc))
                if attempt == 2:
                    raise
    finally:
        port.close()
