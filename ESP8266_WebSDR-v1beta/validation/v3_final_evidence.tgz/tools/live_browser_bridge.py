"""QA only: browser's real radio.js over HTTP -> actual VM USB serial.

This adapter is deliberately excluded from the delivered standalone HTML.
It neither synthesizes nor replays IQ. Bind to loopback and reach it using
an SSH loopback forward while the ESP8266 is attached to the VM.
"""
import argparse
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import serial

ADAPTER = r"""
<script>
// TEST TRANSPORT ONLY. All bytes come from the physical receiver on the VM.
class VmQaPort {
  getInfo() { return {}; }
  async api(action, body) {
    const r = await fetch('/qa/' + action, {method:'POST',
      headers:{'Content-Type':'application/json'}, body:JSON.stringify(body || {})});
    if (!r.ok) throw Error(await r.text());
    return r;
  }
  async open(options) {
    await this.api('open', {baud:options.baudRate});
    const streamState={cancelled:false};
    this.streamState=streamState;
    this.readable=new ReadableStream({
      pull:async c=>{
        try {
          // A pending stream read must stay pending across empty UART polls.
          // Returning without enqueue would leave that read asleep forever.
          while (!streamState.cancelled) {
            const r=await this.api('read');
            const bytes=new Uint8Array(await r.arrayBuffer());
            if (streamState.cancelled) return;
            if (bytes.length) { c.enqueue(bytes); return; }
          }
        } catch(e) { if (!streamState.cancelled) c.error(e); }
      },
      cancel:()=>{ streamState.cancelled=true; }
    });
    this.writable=new WritableStream({
      write:bytes=>this.api('write', {bytes:Array.from(bytes)})
    });
  }
  async setSignals(signals) { await this.api('signals', signals); }
  async close() {
    if (this.streamState) this.streamState.cancelled=true;
    await this.api('close');
    this.readable=null;
    this.writable=null;
  }
}
SerialConnection.supported=()=>true;
SerialConnection.defaultKind=()=> 'webserial';
SerialConnection.requestPort=async()=>new VmQaPort();
SerialConnection.getPorts=async()=>[];
SerialConnection.kind=()=> 'webserial';
const qa=document.createElement('div');
qa.textContent='VALIDATION MATÉRIELLE — USB réel sur la VM, relais HTTP de test. Le HTML livré utilise WebSerial directement.';
qa.style='padding:10px;background:#403416;color:#fff;text-align:center;font:14px sans-serif';
document.body.prepend(qa);
</script>
"""

p = argparse.ArgumentParser()
p.add_argument("--html", required=True)
p.add_argument("--port", type=int, default=8766)
a = p.parse_args()
mutex = threading.Lock()
port = None


class Handler(BaseHTTPRequestHandler):
    def respond(self, code, data=b"", kind="application/octet-stream"):
        self.send_response(code)
        self.send_header("Content-Type", kind)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path in ("/", "/live-test"):
            page = Path(a.html).read_text(encoding="utf-8")
            if self.path == "/live-test":
                page = page.replace("connect-src 'none'", "connect-src 'self'")
                page = page.replace("</body>", ADAPTER + "\n</body>")
            self.respond(200, page.encode(), "text/html; charset=utf-8")
        else:
            self.respond(404)

    def do_POST(self):
        global port
        origin = self.headers.get("Origin")
        allowed = (f"http://localhost:{a.port}", f"http://127.0.0.1:{a.port}")
        if origin and origin not in allowed:
            self.respond(403, b"Loopback QA origin only")
            return
        try:
            n = int(self.headers.get("Content-Length", "0"))
            if n < 0 or n > 65536:
                raise ValueError("Bad body length")
            body = json.loads(self.rfile.read(n) or b"{}")
            data = b""
            with mutex:
                if self.path == "/qa/open":
                    if port:
                        port.close()
                    if body["baud"] not in (115200, 1000000, 2000000):
                        raise ValueError("Bad baud")
                    port = serial.Serial(port=None, baudrate=body["baud"],
                                         timeout=0.06, write_timeout=3, exclusive=True)
                    port.dtr = False
                    port.rts = False
                    port.port = "/dev/ttyUSB0"
                    port.open()
                    print(json.dumps({"event": "open", "baud": port.baudrate}), flush=True)
                elif self.path == "/qa/close":
                    if port:
                        port.close()
                    port = None
                elif not port:
                    raise RuntimeError("Receiver port is closed")
                elif self.path == "/qa/read":
                    data = port.read(max(1, min(65536, port.in_waiting)))
                elif self.path == "/qa/write":
                    raw = bytes(body["bytes"])
                    if len(raw) > 1024:
                        raise ValueError("QA command too long")
                    port.write(raw)
                    port.flush()
                    print(json.dumps({"event": "command",
                                      "ascii": raw.decode("ascii", errors="replace")}), flush=True)
                elif self.path == "/qa/signals":
                    if "dataTerminalReady" in body:
                        port.dtr = bool(body["dataTerminalReady"])
                    if "requestToSend" in body:
                        port.rts = bool(body["requestToSend"])
                else:
                    raise ValueError("Unknown QA action")
            self.respond(200, data)
        except Exception as e:
            self.respond(500, str(e).encode(), "text/plain")

    def log_message(self, fmt, *args):
        if not self.path.startswith("/qa/read"):
            print(fmt % args, flush=True)


server = ThreadingHTTPServer(("127.0.0.1", a.port), Handler)
print(f"QA server at http://127.0.0.1:{a.port}/live-test", flush=True)
try:
    server.serve_forever()
finally:
    server.server_close()
    if port:
        port.close()
