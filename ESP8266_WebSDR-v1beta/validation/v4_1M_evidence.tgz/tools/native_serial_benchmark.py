"""Serial-only benchmark: original Espressif RAM stub, no flash writes or RF.

One selected ESP8266 per invocation. Every bulk read verifies the stub's MD5
and is byte-compared against a reference acquired at 115200. Failed reads
are never retried at that baud. Loader reconnection is recovery, not a pass.
"""
import argparse
import contextlib
import hashlib
import json
import sys
import time
from pathlib import Path

ESPTOOL_DIR = "/home/kaboom/.arduino15/packages/esp8266/hardware/esp8266/3.1.2/tools/esptool"
sys.path.insert(0, ESPTOOL_DIR)
import esptool

p = argparse.ArgumentParser()
p.add_argument("--port", required=True)
p.add_argument("--mac", required=True)
p.add_argument("--out", required=True)
p.add_argument("--rates", default="230400,460800,921600,1000000,1500000,2000000,2500000,3000000,3500000,4000000")
p.add_argument("--stress-seconds", type=float, default=120)
p.add_argument("--block", type=int, default=262144)
p.add_argument("--stress-rate", type=int)
a = p.parse_args()
out = Path(a.out)
out.mkdir(parents=True, exist_ok=False)
log = (out / "esptool.log").open("w", buffering=1)
events = (out / "events.jsonl").open("w", buffering=1)
summary = {
    "port": a.port, "expected_mac": a.mac, "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "method": "unmodified Espressif RAM stub; flash reads only; MD5 + exact reference comparison; no payload retry",
    "esptool_sha256": hashlib.sha256((Path(ESPTOOL_DIR)/"esptool.py").read_bytes()).hexdigest(),
    "block_bytes": a.block, "flash_bytes": 4194304, "rates": [],
}
stub = None


def emit(event, **data):
    row = {"time_ns": time.time_ns(), "event": event, **data}
    events.write(json.dumps(row) + "\n")
    print(json.dumps(row), flush=True)


def save():
    (out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")


def close(reset=False):
    global stub
    if stub is not None:
        try:
            if reset:
                with contextlib.redirect_stdout(log):
                    stub.hard_reset()
        finally:
            stub._port.close()
            stub = None


def connect():
    global stub
    close()
    rom = esptool.ESP8266ROM(a.port, 115200)
    rom._port.exclusive = True
    rom._port.write_timeout = 5
    stub = rom
    with contextlib.redirect_stdout(log):
        rom.connect()
        mac = ":".join(f"{b:02x}" for b in rom.read_mac())
        if mac != a.mac:
            raise RuntimeError(f"Unexpected board: {mac}")
        stub = rom.run_stub()
        summary["observed_mac"] = mac
    emit("connected", mac=mac, baud=115200)


def change(baud):
    with contextlib.redirect_stdout(log):
        stub.change_baud(baud)
        div = stub.read_reg(0x60000014)
    emit("baud_set", requested=baud, reported=stub._port.baudrate, uart_clkdiv=div)
    return div


def block_read(reference=None):
    start = time.monotonic()
    # esptool.read_flash uses SLIP blocks and ACKs, validates the final MD5,
    # and performs no automatic retransmission of failed payloads.
    with contextlib.redirect_stdout(log):
        data = stub.read_flash(0, a.block)
    elapsed = time.monotonic() - start
    if len(data) != a.block:
        raise RuntimeError(f"Length mismatch: {len(data)}")
    if reference is not None and data != reference:
        raise RuntimeError("Reference byte comparison failed")
    return data, elapsed


try:
    connect()
    with contextlib.redirect_stdout(log):
        summary["flash_md5_before"] = stub.flash_md5sum(0, summary["flash_bytes"])
    reference, baseline_seconds = block_read()
    (out / "reference.bin").write_bytes(reference)
    summary["reference_sha256"] = hashlib.sha256(reference).hexdigest()
    summary["reference_distinct_bytes"] = len(set(reference))
    summary["baseline_seconds"] = baseline_seconds
    emit("baseline_pass", bytes=len(reference), seconds=baseline_seconds,
         sha256=summary["reference_sha256"], distinct_bytes=summary["reference_distinct_bytes"])
    save()
    rates = [int(x) for x in a.rates.split(",") if x]
    for baud in rates:
        row = {"baud": baud, "pass": False, "blocks": 0, "bytes": 0, "seconds": 0.0, "payload_retries": 0}
        try:
            # The ESP8266 stub scales/truncates its current UART divisor.
            # Restart from the same ROM-autobaud state for every candidate.
            connect()
            row["uart_clkdiv"] = change(baud)
            for _ in range(2):
                _, seconds = block_read(reference)
                row["blocks"] += 1
                row["bytes"] += a.block
                row["seconds"] += seconds
            row["pass"] = True
            row["bytes_per_second"] = row["bytes"] / row["seconds"]
        except Exception as exc:
            row["error"] = f"{type(exc).__name__}: {exc}"
            close()
        summary["rates"].append(row)
        emit("candidate", **row)
        save()
    passed = [r["baud"] for r in summary["rates"] if r["pass"]]
    if a.stress_rate is not None:
        passed = [a.stress_rate]
    summary["stress"] = []
    # If a candidate fails the sustained run, try the next lower passed rate.
    for baud in sorted(set(passed), reverse=True):
        row = {"baud": baud, "pass": False, "blocks": 0, "bytes": 0, "seconds": 0.0, "payload_retries": 0}
        try:
            connect()
            row["uart_clkdiv"] = change(baud)
            start = time.monotonic()
            last_report = start
            while time.monotonic() - start < a.stress_seconds:
                _, seconds = block_read(reference)
                row["blocks"] += 1
                row["bytes"] += a.block
                row["seconds"] += seconds
                if time.monotonic() - last_report >= 20:
                    emit("stress_progress", **row)
                    last_report = time.monotonic()
            row["pass"] = True
            row["bytes_per_second"] = row["bytes"] / row["seconds"]
        except Exception as exc:
            row["error"] = f"{type(exc).__name__}: {exc}"
            close()
        summary["stress"].append(row)
        emit("stress_result", **row)
        save()
        if row["pass"]:
            summary["maximum_passed_baud"] = baud
            break
    connect()
    with contextlib.redirect_stdout(log):
        summary["flash_md5_after"] = stub.flash_md5sum(0, summary["flash_bytes"])
    summary["flash_unchanged"] = summary["flash_md5_before"] == summary["flash_md5_after"]
    if not summary["flash_unchanged"]:
        raise RuntimeError("Flash MD5 changed despite read-only test")
    summary["completed"] = True
    emit("complete", max_baud=summary.get("maximum_passed_baud"), flash_unchanged=True)
except Exception as exc:
    summary["fatal_error"] = f"{type(exc).__name__}: {exc}"
    emit("fatal", error=summary["fatal_error"])
    raise
finally:
    close(reset=True)
    summary["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    save()
    events.close()
    log.close()
